
package edu.cuc.listaSimple;

/**
 *
 * @author Gcastro21
 */
public class PruebaAdicionarAlFinal {

    
    public static void main(String[] args) {
        ListaSimple<Integer> listaNumeros01 = new ListaSimple<>();
        listaNumeros01.adicionarAlInicio(1);
        listaNumeros01.adicionarAlInicio(2);
        listaNumeros01.adicionarAlInicio(3);
        listaNumeros01.adicionarAlInicio(4);
        System.out.println(listaNumeros01);
        listaNumeros01.adicinarAlFinal(5);
        System.out.println(listaNumeros01);
        
    }
    
}
