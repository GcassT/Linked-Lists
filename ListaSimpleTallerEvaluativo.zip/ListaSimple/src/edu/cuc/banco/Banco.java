
package edu.cuc.banco;

import edu.cuc.listaSimple.ListaSimple;
import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author Gcastro21
 */
public class Banco {
    //ATRIBUTOS
    private String nombreBanco;
    private ListaSimple<Cuenta> listaCuentas = new ListaSimple<>();

    //CONSTRUCTORES
    public Banco(String nombreBanco) {
        this.nombreBanco = nombreBanco;
    }
    
    //GETTERS Y SETTERS
    public String getNombreBanco() {
        return nombreBanco;
    }

    public void setNombreBanco(String nombreBanco) {
        this.nombreBanco = nombreBanco;
    }
    
    public String verListaCuentas() {
        return listaCuentas.toString();
    }
    
    //TOSTRING
    @Override
    public String toString() {
        return "Banco{" + "nombreBanco= " + nombreBanco + ", listaCuentas= " + listaCuentas + '}';
    }
    
   //EQUALS

    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Banco other = (Banco) obj;
        if (!Objects.equals(this.nombreBanco, other.nombreBanco)) {
            return false;
        }
        if (!Objects.equals(this.listaCuentas, other.listaCuentas)) {
            return false;
        }
        return true;
    }
   
    
    //MÉTODOS PROPIOS DE LA CLASE
    
    public void adicionarCuenta(String nombreTitular, int numeroCuenta, double saldoInicial) {
        Cuenta cuenta = new Cuenta(nombreTitular, numeroCuenta, saldoInicial);
        listaCuentas.adicionarAlInicio(cuenta);
    }
    
    public boolean buscarCuenta(int numeroCuenta) {
        for (int i = 0; i < listaCuentas.longitud(); i++) {
            Cuenta actual = listaCuentas.get(i);
            if(actual.getNumeroCuenta() == numeroCuenta) {
                return true;
            }
        }
        return false;
    }
    public boolean eliminarCuenta(int numeroCuenta) {
        for (int i = 0; i < listaCuentas.longitud(); i++) {
            Cuenta actual = listaCuentas.get(i);
            if(actual.getNumeroCuenta() == numeroCuenta) {
                listaCuentas.eliminar(actual);
                return true;
            }
        }
        return false;
    }
    
    

    public ListaSimple<Cuenta> buscarPorSaldos(Double saldo) {
        
        ListaSimple<Cuenta> nuevaLista = new ListaSimple<>();
        
        for (int i = 0; i < listaCuentas.longitud(); i++) {
            Cuenta actual = listaCuentas.get(i);
            if(actual.getSaldo() == saldo) {
                nuevaLista.adicionarAlInicio(actual);
            }
        }
        return nuevaLista;
    }
 
    public ListaSimple<Cuenta> buscarCuentaPorNombre(String nombre) {
        ListaSimple<Cuenta> nuevaLista = new ListaSimple<>();
        for (int i = 0; i < listaCuentas.longitud(); i++) {
            Cuenta actual = listaCuentas.get(i);
            if(actual.getNombreTitular().equals(nombre)) {
                nuevaLista.adicionarAlInicio(actual);
            }
        }
        return nuevaLista;
    }
    
    //INDICAR EL PROMEDIO DE LOS SALDOS DE LAS CUENTAS
     public double promedioSaldos(){
        if (listaCuentas.estaVacia()) {
            return 0;
        } else {
            double sumaSaldos = 0;
           
            for (int i = 0; i < listaCuentas.longitud(); i++) {
                Cuenta datoActual = listaCuentas.buscarPorPosicion(i);
                sumaSaldos += datoActual.getSaldo();
                
            }
            double promedioSaldos = sumaSaldos / listaCuentas.longitud();
            return promedioSaldos;
        }
    
    }
     
     //BUSCAR CUENTAS PARA UN MISMO TITULAR DADO
     public ArrayList<Cuenta> cuentasUsuario(String nombreTitular){
         if (listaCuentas.estaVacia()) {
             return null;
         } else {
             ArrayList<Cuenta> cuentasResultado = new ArrayList<>();
             for (int i = 0; i < listaCuentas.longitud(); i++) {
                 Cuenta cuentaActual = listaCuentas.get(i);
                 if (cuentaActual.getNombreTitular().equalsIgnoreCase(nombreTitular)) {
                     cuentasResultado.add(cuentaActual);
                 }
                 
             }
             return cuentasResultado;
         }
     }
     
     //INDICAR LA CUENTA CON MAYOR SALDO
     public ListaSimple<Cuenta> mayorSaldo(){
         if (listaCuentas.estaVacia()) {
             return null;
         } else {
            double saldoMayor = 0;
             for (int i = 0; i < listaCuentas.longitud(); i++) {
                 Cuenta cuentaActual = listaCuentas.get(i);
                 if (cuentaActual.getSaldo() > saldoMayor) {
                     saldoMayor = cuentaActual.getSaldo();
                 }
                 
             }
             return buscarPorSaldos(saldoMayor);
         }
     }
     
     //ELIMINAR CUENTA CON MAYOR SALDO 
     public String eliminarSaldoMayor(){
         if (listaCuentas.estaVacia()) {
             return "La lista está vacía";
         } else {
             boolean eliminado = false;
             double saldoMayor = 0;
             for (int i = 0; i < listaCuentas.longitud(); i++) {
                 Cuenta cuentaActual = listaCuentas.get(i);
                 if (cuentaActual.getSaldo() > saldoMayor) {
                     saldoMayor = cuentaActual.getSaldo();
                 }
                 
             }
             for (int i = 0; i < listaCuentas.longitud(); i++) {
                 Cuenta cuentaActual = listaCuentas.get(i);
                 if (saldoMayor == cuentaActual.getSaldo()) {
                     listaCuentas.eliminar(cuentaActual);
                     eliminado = true;
                 }
                 
             }
             if (eliminado) {
                 return "Cuenta eliminada de forma exitosa!";
             }
             else{
                 return "Ocurrió un error al eliminar la cuenta!";
             }
             
         }
     }
     
     
     
     
     
     
     
     
     
}
