
package edu.cuc.banco;

/**
 *
* @author Gcastro21
 */
public class PruebaListaCuentas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Banco banco01 = new Banco ("pichcincha");
        Banco banco02 = new Banco("Davivienda");
        banco01.adicionarCuenta("luis", 001, 24.200);
        banco01.adicionarCuenta("juan", 002, 234.500);
        banco01.adicionarCuenta("randy", 003, 2.000);
        banco01.adicionarCuenta("andrea", 003, 1.239);
        banco01.adicionarCuenta("gian", 004, 600.000);
        System.out.println(banco01.toString());
        banco01.eliminarCuenta(002);
        System.out.println("Lista actualizada: "+banco01.verListaCuentas());
        
        
    }
    
}
