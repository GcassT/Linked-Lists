/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.cuc.listaSimple;

/**
 *
 * @author Gian Castro
 */
public class pruebaElementosEntrePosiciones {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ListaSimple<String> listaPalabras = new ListaSimple<>();
        
        listaPalabras.adicionarAlInicio("fiore");
        listaPalabras.adicionarAlInicio("lesly");
        listaPalabras.adicionarAlInicio("gian");
        listaPalabras.adicionarAlInicio("franco");
        listaPalabras.adicionarAlInicio("jean");
        listaPalabras.adicionarAlInicio("mara");
        System.out.println(listaPalabras);
        
        System.out.println("Las palabras entre esas posiciones son: "+listaPalabras.elementosEntrePosiciones(1, 3));
    }
    
}
