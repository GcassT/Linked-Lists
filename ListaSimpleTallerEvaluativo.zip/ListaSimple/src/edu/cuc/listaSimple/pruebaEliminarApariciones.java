/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.cuc.listaSimple;

/**
 *
 * @author Gian Castro
 */
public class pruebaEliminarApariciones {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ListaSimple<Integer> listaNumeros = new ListaSimple<>();
        
        listaNumeros.adicionarAlInicio(2);
        listaNumeros.adicionarAlInicio(2);
        listaNumeros.adicionarAlInicio(2);
        listaNumeros.adicionarAlInicio(2);
        listaNumeros.adicionarAlInicio(16);
        listaNumeros.adicionarAlInicio(16);
        listaNumeros.adicionarAlInicio(2);
        System.out.println(listaNumeros);
        
        System.out.println("Eliminar apariciones: "+listaNumeros.eliminarApariciones(2));
        System.out.println(listaNumeros);
    }
    
}
