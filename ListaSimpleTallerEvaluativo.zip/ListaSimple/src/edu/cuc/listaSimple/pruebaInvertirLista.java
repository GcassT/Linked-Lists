/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.cuc.listaSimple;

/**
 *
 * @author Gian Castro
 */
public class pruebaInvertirLista {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ListaSimple<Integer> listaNumeros = new ListaSimple<>();
        
        listaNumeros.adicionarAlInicio(1);
        listaNumeros.adicionarAlInicio(2);
        listaNumeros.adicionarAlInicio(3);
        listaNumeros.adicionarAlInicio(4);
        listaNumeros.adicionarAlInicio(5);
        listaNumeros.adicionarAlInicio(6);
        System.out.println("Lista: "+listaNumeros);
    
        System.out.println("Lista actualizada: "+listaNumeros.invertirLista());
             
    }
    
}
