/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.cuc.listaSimple;

/**
 *
 * @author Gian Castro
 */
public class pruebaPenultimoDatoLista {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ListaSimple<Double> listaRacionales = new ListaSimple<>();
        
        listaRacionales.adicionarAlInicio(2.0);
        listaRacionales.adicionarAlInicio(78.0);
        listaRacionales.adicionarAlInicio(1234.0);
        listaRacionales.adicionarAlInicio(129.0);
        listaRacionales.adicionarAlInicio(8937.0);
        
        //MOSTRAMOS LA LISTA CREADA
        System.out.println(listaRacionales);
        System.out.println("El penúltimo elemento de la lista es:"+listaRacionales.penultimoDatoLista());
        
    }
    
}
