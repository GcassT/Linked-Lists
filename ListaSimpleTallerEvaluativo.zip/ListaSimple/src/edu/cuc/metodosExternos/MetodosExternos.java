/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.cuc.metodosExternos;

import edu.cuc.listaSimple.ListaSimple;
import java.util.ArrayList;

/**
 *
 * @author gcastro21
 */
public class MetodosExternos {
    public static int mayorLista(ListaSimple<Integer> listaNumeros){
        if (listaNumeros.estaVacia()) {
            return -1;
        }
        else {
        int numeroMayor = listaNumeros.get(0);
            for (int i = 0; i < listaNumeros.longitud(); i++) {
                Integer datoActual = listaNumeros.get(i);
                if (datoActual > numeroMayor) {
                    numeroMayor = datoActual;
                }
                
            }
        return numeroMayor;
        }
    }
    //LISTA PARTIDARIA 
    public static boolean listaPartidaria(ListaSimple<Integer> listaNumeros){
        if (listaNumeros.estaVacia()) {
            return false;
        } else {
            ArrayList<Integer> listaPares = new ArrayList<>();
            ArrayList<Integer> listaImpares = new ArrayList<>();
            int posicion = 0;
            for (int i = 0; i < listaNumeros.longitud(); i++) {
                posicion ++;
                Integer datoActual = listaNumeros.get(i);
                if (posicion %2 == 0) {
                    listaPares.add(datoActual);
                } else {
                    listaImpares.add(datoActual);
                }
                
            }
           int contador02 = 0;
           int posicion02 = 0;
            for (int i = 0; i < listaPares.size(); i++) {
                for (int j = 0; j < listaImpares.size(); j++) {
                    if (listaPares.get(posicion02) > listaImpares.get(i)) {
                        contador02 ++;
                        posicion02++;
                        
                        if (contador02 >= listaPares.size()) {
                            return true;
                        }
                        
                    }
                }
            }
        }
        return false;
    }
}
