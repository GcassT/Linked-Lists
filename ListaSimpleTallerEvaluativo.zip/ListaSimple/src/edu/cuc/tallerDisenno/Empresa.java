/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.cuc.tallerDisenno;

import edu.cuc.listaSimple.ListaSimple;
import java.util.ArrayList;

/**
 *
 * @author gcastro21
 */
public class Empresa {
    //ATRIBUTOS
    private String nombreEmpresa;
    private ListaSimple<Estudiante> listaEstudiantes = new ListaSimple<>();
    
    //CONSTRUCTOR

    public Empresa(String nombreEmpresa) {
        this.nombreEmpresa = nombreEmpresa;
    }

    //GETTER Y SETTER

    public String getNombreEmpresa() {
        return nombreEmpresa;
    }

    public void setNombreEmpresa(String nombreEmpresa) {
        this.nombreEmpresa = nombreEmpresa;
    }
    
    //TOSTRING

    @Override
    public String toString() {
        return "ClaseLista{" + "nombreEmpresa= " + nombreEmpresa + ", listaEstudiantes= " + listaEstudiantes + '}';
    }
    
    //MÉTODOS PROPIOS DE LA CLASE
    
    //ADICIONAR
      public void adicionarEstudiante(int codigoEstudiante , String nombreEstudiante 
     , double nota01, double nota02, double nota03, double nota04, double nota05) {
        Estudiante estudiante01 = new Estudiante (codigoEstudiante ,  nombreEstudiante 
     , nota01, nota02, nota03,  nota04,  nota05);
        listaEstudiantes.adicionarAlInicio(estudiante01);
    }
    //BUSCAR 
    public boolean buscarEstudiante(int codigoEstudiante) {
        for (int i = 0; i < listaEstudiantes.longitud(); i++) {
            Estudiante actual = listaEstudiantes.get(i);
            if(actual.getCodigoEstudiante()== codigoEstudiante) {
                return true;
            }
        }
        return false;
    }
    //ELIMINAR
    public boolean eliminarEstudiante(int codigoEstudiante) {
        for (int i = 0; i < listaEstudiantes.longitud(); i++) {
            Estudiante actual = listaEstudiantes.get(i);
            if(actual.getCodigoEstudiante()== codigoEstudiante) {
                listaEstudiantes.eliminar(actual);
                return true;
            }
        }
        return false;
    }
    
    //PROMEDIO INDICADO POR EL USUARIO
    public ArrayList<Estudiante> promedioEstudiante(double promedioEstudiante){
        if (listaEstudiantes.estaVacia()) {
            return null;
        } else {
            ArrayList<Estudiante> listaResultado = new ArrayList<>();
            double promedioActual = 0;
            double sumaNotas = 0;
            for (int i = 0; i < listaEstudiantes.longitud(); i++) {
                Estudiante estudianteActual = listaEstudiantes.get(i);
                sumaNotas =  (estudianteActual.getNota01()*0.2) + 
(estudianteActual.getNota02()*0.2) + (estudianteActual.getNota03()*0.2) 
+ (estudianteActual.getNota04()*0.2) + (estudianteActual.getNota05()*0.2);
                promedioActual = sumaNotas/5;
                
                if (promedioActual == promedioEstudiante) {
                    listaResultado.add(estudianteActual);
                }
                
                
            }
            return listaResultado;
        }
    
    }
    
    //NOTAS APROBADAS MAYORES O IGUALES A 3
    public ArrayList<Estudiante> aprobados(){
    ArrayList<Estudiante> listaAprobados = new ArrayList<>();
    int contador = 0;
        for (int i = 0; i < listaEstudiantes.longitud(); i++) {
            Estudiante estudianteActual = listaEstudiantes.get(i);
            if (estudianteActual.getNota01()>= 3.0) {
                contador++;
            }
            else if(estudianteActual.getNota02()>= 3.0){
            contador++;
            }
            else if (estudianteActual.getNota03() >= 3.0) {
             contador++;
            }
            else if (estudianteActual.getNota04()>= 3.0) {
                contador++;
            }
            else if (estudianteActual.getNota05() >= 3.0) {
                contador++;
            }
            if (contador >= 2) {
                listaAprobados.add(estudianteActual);
            }
        }
    return listaAprobados;
    
    }
    
    
    
    
}
