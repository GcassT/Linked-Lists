/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.cuc.tallerDisenno;

import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author gcastro21
 */
public class Estudiante {
    //ATRIBUTOS
    private int codigoEstudiante;
    private String nombreEstudiante;
    private double nota01, nota02, nota03, nota04, nota05;
    
    
    //CONSTRUCTORES
    public Estudiante(int codigoEstudiante, String nombreEstudiante, double nota01, double nota02, double nota03, double nota04, double nota05) {
        this.codigoEstudiante = codigoEstudiante;
        this.nombreEstudiante = nombreEstudiante;
        this.nota01 = nota01;
        this.nota02 = nota02;
        this.nota03 = nota03;
        this.nota04 = nota04;
        this.nota05 = nota05;
    }
    
    //GETTERS Y SETTERS

    public int getCodigoEstudiante() {
        return codigoEstudiante;
    }

    public void setCodigoEstudiante(int codigoEstudiante) {
        this.codigoEstudiante = codigoEstudiante;
    }

    public String getNombreEstudiante() {
        return nombreEstudiante;
    }

    public void setNombreEstudiante(String nombreEstudiante) {
        this.nombreEstudiante = nombreEstudiante;
    }

    public double getNota01() {
        return nota01;
    }

    public void setNota01(double nota01) {
        this.nota01 = nota01;
    }

    public double getNota02() {
        return nota02;
    }

    public void setNota02(double nota02) {
        this.nota02 = nota02;
    }

    public double getNota03() {
        return nota03;
    }

    public void setNota03(double nota03) {
        this.nota03 = nota03;
    }

    public double getNota04() {
        return nota04;
    }

    public void setNota04(double nota04) {
        this.nota04 = nota04;
    }

    public double getNota05() {
        return nota05;
    }

    public void setNota05(double nota05) {
        this.nota05 = nota05;
    }
    
    //TOSTRING

    @Override
    public String toString() {
        return "Estudiante{" + "codigoEstudiante=" + codigoEstudiante + ", nombreEstudiante=" + nombreEstudiante + ", nota01=" + nota01 + ", nota02=" + nota02 + ", nota03=" + nota03 + ", nota04=" + nota04 + ", nota05=" + nota05 + '}';
    }
    
  
    
    
    //EQUALS

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 23 * hash + this.codigoEstudiante;
        hash = 23 * hash + Objects.hashCode(this.nombreEstudiante);
        hash = 23 * hash + (int) (Double.doubleToLongBits(this.nota01) ^ (Double.doubleToLongBits(this.nota01) >>> 32));
        hash = 23 * hash + (int) (Double.doubleToLongBits(this.nota02) ^ (Double.doubleToLongBits(this.nota02) >>> 32));
        hash = 23 * hash + (int) (Double.doubleToLongBits(this.nota03) ^ (Double.doubleToLongBits(this.nota03) >>> 32));
        hash = 23 * hash + (int) (Double.doubleToLongBits(this.nota04) ^ (Double.doubleToLongBits(this.nota04) >>> 32));
        hash = 23 * hash + (int) (Double.doubleToLongBits(this.nota05) ^ (Double.doubleToLongBits(this.nota05) >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Estudiante other = (Estudiante) obj;
        if (this.codigoEstudiante != other.codigoEstudiante) {
            return false;
        }
        if (Double.doubleToLongBits(this.nota01) != Double.doubleToLongBits(other.nota01)) {
            return false;
        }
        if (Double.doubleToLongBits(this.nota02) != Double.doubleToLongBits(other.nota02)) {
            return false;
        }
        if (Double.doubleToLongBits(this.nota03) != Double.doubleToLongBits(other.nota03)) {
            return false;
        }
        if (Double.doubleToLongBits(this.nota04) != Double.doubleToLongBits(other.nota04)) {
            return false;
        }
        if (Double.doubleToLongBits(this.nota05) != Double.doubleToLongBits(other.nota05)) {
            return false;
        }
        if (!Objects.equals(this.nombreEstudiante, other.nombreEstudiante)) {
            return false;
        }
        return true;
    }
    
    
    
    
}
