/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.cuc.tallerDisenno;

/**
 *
 * @author gcastro21
 */
public class PruebaEstudiantes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Empresa empresa01 = new Empresa("Unicosta");
        empresa01.adicionarEstudiante(01, "Luis", 1.0, 3.4, 2.6, 4.8, 4.0);
        empresa01.adicionarEstudiante(02, "Juan", 3.0, 3.4, 4.6, 2.8, 5.0);
        empresa01.adicionarEstudiante(03, "Alberto", 5.0, 3.4, 3.6, 3.8, 4.0);
        empresa01.adicionarEstudiante(04, "Gian", 1.0, 1.4, 2.6, 1.8, 4.0);
        empresa01.adicionarEstudiante(05, "Eliminar", 1.0, 3.4, 2.6, 4.8, 4.0);
        System.out.println(empresa01.toString());
        System.out.println("Estudiante eliminado: "+empresa01.eliminarEstudiante(05));
        System.out.println("Lista actualizada: "+empresa01.toString());
        System.out.println("Estudiante encontrado: "+empresa01.buscarEstudiante(02));
        //PRUEBA PROMEDIO
        System.out.println(empresa01.promedioEstudiante(0.632)); //ENCUENTRA EL PROMEDIO EXACTO PROBADO CON LA CALCULADORA
        System.out.println(empresa01.promedioEstudiante(0.752));
        
        //PRUEBA APROBADOS
        System.out.println("Aprobados: "+empresa01.aprobados());
        
        
    }
    
}
