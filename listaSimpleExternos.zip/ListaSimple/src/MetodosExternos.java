
import edu.cuc.banco.Banco;
import edu.cuc.listaSimple.ListaSimple;
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Gian Castro
 */
public class MetodosExternos {
    //MAYOR DE UNA LISTA DE ENTEROS 
    public static int mayorLista(ListaSimple<Integer> listaNumeros){
        if (listaNumeros.estaVacia()) {
            return -1;
        }
        else {
        int numeroMayor = listaNumeros.get(0);
            for (int i = 0; i < listaNumeros.longitud(); i++) {
                Integer datoActual = listaNumeros.get(i);
                if (datoActual > numeroMayor) {
                    numeroMayor = datoActual;
                }
                
            }
        return numeroMayor;
        }
    }
    //LISTA PARTIDARIA 
    public static boolean listaPartidaria(ListaSimple<Integer> listaNumeros){
        if (listaNumeros.estaVacia()) {
            return false;
        } else {
            ArrayList<Integer> listaPares = new ArrayList<>();
            ArrayList<Integer> listaImpares = new ArrayList<>();
            int posicion = 0;
            for (int i = 0; i < listaNumeros.longitud(); i++) {
                posicion ++;
                Integer datoActual = listaNumeros.get(i);
                if (posicion %2 == 0) {
                    listaPares.add(datoActual);
                } else {
                    listaImpares.add(datoActual);
                }
                
            }
           int contador02 = 0;
           int posicion02 = 0;
            for (int i = 0; i < listaPares.size(); i++) {
                for (int j = 0; j < listaImpares.size(); j++) {
                    if (listaPares.get(posicion02) > listaImpares.get(i)) {
                        contador02 ++;
                        posicion02++;
                        
                        if (contador02 >= listaPares.size()) {
                            return true;
                        }
                        
                    }
                }
            }
        }
        return false;
    }
    
 
    
    
    
    
    public static void main(String[] args) {
        
        ListaSimple<Integer> listaNumeros = new ListaSimple<>();
        listaNumeros.adicionarAlInicio(2); //0
        listaNumeros.adicionarAlInicio(1); //1
        listaNumeros.adicionarAlInicio(2); //2
        listaNumeros.adicionarAlInicio(1); //3
        listaNumeros.adicionarAlInicio(2); //4
       listaNumeros.adicionarAlInicio(1); //5
        System.out.println("Partidaria: "+MetodosExternos.listaPartidaria(listaNumeros));
        
    }
    
    
    
    
    
    
    
}
