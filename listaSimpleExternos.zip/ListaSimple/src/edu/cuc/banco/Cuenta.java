/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.cuc.banco;

import java.util.Objects;

/**
 *
* @author Gcastro21
 */
public class Cuenta {
    
    //ATRIBUTOS
    private String nombre;
    private int numeroCuenta;
    private double saldo;

    //CONSTRUCTORES

    public Cuenta(String nombre, int numeroCuenta, double saldo) {
        this.nombre = nombre;
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldo;
    }


    //GETTERS
    public String getNombre() {
        return nombre;
    }

    public int getNumeroCuenta() {
        return numeroCuenta;
    }

    public double getSaldo() {
        return saldo;
    }

    //SETTERS
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


    //TOSTRING
    @Override
    public String toString() {
        return "Cuenta{" + "nombre= " + nombre +  ", numeroCuenta= " + numeroCuenta + "}";
    }

    @Override
    public int hashCode() {
        int hash = 5;
        return hash;
    }
  

   

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cuenta other = (Cuenta) obj;
        if (this.numeroCuenta != other.numeroCuenta) {
            return false;
        }
        if (Double.doubleToLongBits(this.saldo) != Double.doubleToLongBits(other.saldo)) {
            return false;
        }
        return Objects.equals(this.nombre, other.nombre);
    }
    
    
    
     //MÉTODOS PROPIOS DE LA CLASE
    public String consultarSaldo() {
        return "Su saldo es de: " + saldo +" pesos!";
    }

    public void consignar(double valorConsignado) {
        if (valorConsignado > 0) {
            this.saldo += valorConsignado;
        }
    }

    public void retirar(double valorRetirado) {
        if (valorRetirado > 0 && valorRetirado <= this.saldo) {
            this.saldo -= valorRetirado;
        }
    }

    public void transferir(double transferencia, Cuenta cuenta02) {
        if (transferencia > 0 && transferencia <= this.saldo) {
            cuenta02.consignar(transferencia);
            this.retirar(transferencia);
        }
    }
    
    
    
    
    
}
