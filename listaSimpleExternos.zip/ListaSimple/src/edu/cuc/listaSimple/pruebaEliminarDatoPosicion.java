/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.cuc.listaSimple;

/**
 *
 * @author Gian Castro
 */
public class pruebaEliminarDatoPosicion {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       ListaSimple<String> listaNombres = new ListaSimple <>();
       
       listaNombres.adicionarAlInicio("gian");
       listaNombres.adicionarAlInicio("fio");
       listaNombres.adicionarAlInicio("andres");
       listaNombres.adicionarAlInicio("gian");
        System.out.println("Lista : "+listaNombres);
        
        System.out.println("Nombre eliminado: "+listaNombres.eliminarElementoPorPosicion(1));
        
        System.out.println("Lista actualizada: "+listaNombres);
    }
    
}
