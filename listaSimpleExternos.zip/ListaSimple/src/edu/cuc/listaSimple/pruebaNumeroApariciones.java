/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.cuc.listaSimple;

/**
 *
 * @author Gian Castro
 */
public class pruebaNumeroApariciones {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ListaSimple <Integer> listaNumeros = new ListaSimple<>();
        
        listaNumeros.adicionarAlInicio(1);
        listaNumeros.adicionarAlInicio(1);
        listaNumeros.adicionarAlInicio(1);
        listaNumeros.adicionarAlInicio(1);
        listaNumeros.adicionarAlInicio(5);
        listaNumeros.adicionarAlInicio(6);
        listaNumeros.adicionarAlInicio(3);
        //LISTA INICIAL
        System.out.println(listaNumeros);
        System.out.println("El número de apariciones del dato es: "+listaNumeros.numeroApariciones(1));
        //LISTA RESULTANTE
        
        
    }
    
}
