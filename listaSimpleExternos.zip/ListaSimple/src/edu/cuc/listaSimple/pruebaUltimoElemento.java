/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edu.cuc.listaSimple;

/**
 *
 * @author Gian Castro
 */
public class pruebaUltimoElemento {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ListaSimple <String> listaPalabras = new ListaSimple<>();
        
        listaPalabras.adicionarAlInicio("juan");
        listaPalabras.adicionarAlInicio("hernan");
        listaPalabras.adicionarAlInicio("camila");
        listaPalabras.adicionarAlInicio("angie");
        listaPalabras.adicionarAlInicio("gonzalez");
        System.out.println(listaPalabras);
        
        System.out.println(listaPalabras.ultimoDatoLista());
    }
    
}
